function [idx] = UniformColSampling(A, c)

m = size(A, 2);
randIdx = randperm(m);
idx = randIdx(1:c);
idx = sort(idx, 'ascend');

end
