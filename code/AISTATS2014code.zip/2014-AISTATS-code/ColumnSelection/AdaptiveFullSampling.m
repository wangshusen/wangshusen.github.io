function [idx] = AdaptiveFullSampling(A, c)

c1 = ceil(c/3);
c2 = c1;
c3 = c - c1 - c2;

[n] = size(A, 2);

% Uniformly Sampling: c1 columns
randIdx = randperm(n);
idx1 = randIdx(1:c1);
C1 = A(:, idx1);

% Adaptive Sampling Round 1: c2 columns
res = C1 * (pinv(C1) * A);
clear C1;
res = A - res;

resNorm = ones(n, 1);
for i = 1: n
    resNorm(i) = norm(res(:, i))^2;
end
clear res;
prob = resNorm / sum(resNorm);
[idx2] = AdaptiveSampling(prob, c2);
idx2 = [idx1, idx2];
C2 = A(:, idx2);

% Adaptive Sampling Round 2: c3 columns
res = C2 * (pinv(C2) * A);
clear C2;
res = A - res;

resNorm = ones(n, 1);
for i = 1: n
    resNorm(i) = norm(res(:, i))^2;
end
clear res;
prob = resNorm / sum(resNorm);
[idx3] = AdaptiveSampling(prob, c3);

idx = [idx2, idx3];
idx = sort(idx, 'ascend');
end
