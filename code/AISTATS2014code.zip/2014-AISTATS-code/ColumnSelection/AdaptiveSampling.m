function [idx] = AdaptiveSampling(prob, r)

n = length(prob);

iter = 0;
flag = false;
while true
    iter = iter + 1;
    selected = binornd(1, 1.5*min(1, r * prob));
    selected = (selected == 1);
    if sum(selected) >= r
        break;
    end
    if iter > 20
        flag = true;
        break;
    end
end

index = 1:n;
idx = index(~~selected);

if flag == false
    idx = idx(1:r); % more than r columns are selected
end

end