function [idx] = AdaptiveNearOptColSampling(A, k, c)

epsilon = sqrt(2*k/c);
c1 = ceil(2 * k / epsilon);
c2 = c - c1;

[m n] = size(A);

% Near-Optimal Column Selection
[idx1] = NearOptColSelect(A, k, c1);
idxTmp = 1: n;
idx1 = idxTmp(idx1);
C1 = A(:, idx1);

% Adaptive Sampling
res = C1 * (pinv(C1) * A);
clear C1;
res = A - res;
clear A;

resNorm = ones(n, 1);
for i = 1: n
    resNorm(i) = norm(res(:, i))^2;
end

prob = resNorm / sum(resNorm);

[idx2] = AdaptiveSampling(prob, c2);

idx = [idx1, idx2];
idx = sort(idx, 'ascend');

end
