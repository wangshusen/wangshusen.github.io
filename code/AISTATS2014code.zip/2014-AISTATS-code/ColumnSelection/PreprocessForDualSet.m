%% Delta_U for the Dual Set Sparsification in the First Stage
AresFroSq = norm(Ares, 'fro')^2;
deltaU1 = AresFroSq / (1 - sqrt(k / c1));

uu1 = zeros(n, 1);
for iU = 1: n
    uu1(iU) = norm(Ares(:, iU))^2;
end
uu1 = uu1 / deltaU1;

%% Delta_U for the Dual Set Sparsification in the Second Stage
deltaU2 = AresFroSq / (1 - sqrt(k / r1));

Ares2 = Ares';
clear Ares;
uu2 = zeros(m, 1);
for iU = 1: m
    uu2(iU) = norm(Ares2(:, iU))^2;
end
uu2 = uu2 / deltaU2;

%save -v7.3 ./ImprovedCUR/tmp/tmp_ImprovedCUR_DualSet.mat uu1 uu2 deltaU1 deltaU2
clear Ares2 AresFroSq deltaU1 deltaU2 iU; 