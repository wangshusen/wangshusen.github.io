plot(standard_uniform.c / m, standard_uniform.error, '-g', 'LineWidth', 2.5);
hold;
plot(standard_uniform_adaptive2.c / m, standard_uniform_adaptive2.error, '-r', 'LineWidth', 2.5);
plot(standard_near_opt_adaptive.c / m, standard_near_opt_adaptive.error, '-b', 'LineWidth', 2.5);
plot(modified_uniform.c / m, modified_uniform.error, '-.og', 'LineWidth', 2.5);
plot(modified_uniform_adaptive2.c / m, modified_uniform_adaptive2.error, '--*r', 'LineWidth', 2.5);
plot(modified_near_opt_adaptive.c / m, modified_near_opt_adaptive.error, ':xb', 'LineWidth', 2.5);

ylabel('Approximation Error','fontsize', 16); 
xlabel('c/n','fontsize', 20);
legend('Standard (uniform sampling)', 'Standard (uniform+adaptive^2)', 'Standard (near-optimal+adaptive)', 'Modified (uniform sampling)', 'Modified (uniform+adaptive^2)', 'Modified (near-optimal+adaptive)');
title('Approximation Error','fontsize', 20);
hold;