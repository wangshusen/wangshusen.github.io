k = 20; % to be tuned
sigma = 0.2; % to be tuned
c = [60: 30: 300]; % to be tuned


setup
maxNumCompThreads(1)

data_name = 'breast-cancer';
load('.\Data\breast-cancer.mat')
X = full(X);
K = rbf(X, sigma); 
m = size(X, 1);

sampling = 'uniform';
[standard_uniform] = TestNystroms(K, k, sampling, 'standard', data_name, c)
[modified_uniform] = TestNystroms(K, k, sampling, 'modified', data_name, c) 
 
sampling = 'uniform-adaptive2';
[standard_uniform_adaptive2] = TestNystroms(K, k, sampling, 'standard', data_name, c)
[modified_uniform_adaptive2] = TestNystroms(K, k, sampling, 'modified', data_name, c)
 
sampling = 'near-opt-adaptive';
[standard_near_opt_adaptive] = TestNystroms(K, k, sampling, 'standard', data_name, c)
[modified_near_opt_adaptive] = TestNystroms(K, k, sampling, 'modified', data_name, c)

save([data_name, '_k', int2str(k), '.mat'], 'm', 'standard_uniform', 'modified_uniform', ...
'standard_uniform_adaptive2', 'modified_uniform_adaptive2', ... 
'standard_near_opt_adaptive', 'modified_near_opt_adaptive');

PlotError