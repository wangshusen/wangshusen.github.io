function [err, time] = ErrorNystroms(K, k, c, sampling, method)

repeat = 10;
normK = norm(K, 'fro');
m = size(K, 1);
Im = eye(m);

errors = zeros(repeat, 1);
tic;
t1 = toc;
for iter = 1: repeat
    if strcmp(method, 'standard')
        [C, U] = StandardNystrom(K, k, c, sampling);
        errors(iter) = norm(K - C*U*C', 'fro') / normK;
    elseif strcmp(method, 'modified')
        [C, U] = ModifiedNystrom(K, k, c, sampling);
        errors(iter) = norm(K - C*U*C', 'fro') / normK;
    else
        return;
    end
end
t2 = toc;

err = min(errors);
time = (t2-t1) / repeat;

end