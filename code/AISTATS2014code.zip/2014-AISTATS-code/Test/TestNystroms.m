function [result] = TestNystroms(K, k, sampling, method, data_name, c)

if nargin < 6
    c = 2*k: 20: 0.2*size(K,1);
end

len = length(c);
time = zeros(len, 1);
error = zeros(len, 1);
tic;

for i = 1: len
    c(i)
    [err, t] = ErrorNystroms(K, k, c(i), sampling, method);
    error(i) = err;
    time(i) = t;
    result.error = error;
    result.time = time;
    result.c = c;
    filename = ['result\',data_name, '_k',int2str(k),'_', method, '_', sampling, '.mat'];
    save(filename, 'result');
end


end