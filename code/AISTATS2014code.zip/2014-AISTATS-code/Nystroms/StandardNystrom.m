function [C, U] = StandardNystrom(K, k, c, sampling)

if nargin < 4
    sampling = 'uniform';
end

% Column Selection
if strcmp(sampling, 'uniform')
    idx = UniformColSampling(K, c);
elseif strcmp(sampling, 'uniform-adaptive2')
    idx = Adaptive2UniformColSampling(K, k, c);
elseif strcmp(sampling, 'near-opt-adaptive')
    idx = AdaptiveNearOptColSampling(K, k, c);
elseif strcmp(sampling, 'adaptive-full')
    idx = AdaptiveFullSampling(K, c);
else
    return;
end

% The Standard Nystrom Approximation
C = K(:, idx);
W = C(idx, :);
U = pinv(W);

end