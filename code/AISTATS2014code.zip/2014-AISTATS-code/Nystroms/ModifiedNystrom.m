function [C, U] = ModifiedNystrom(K, k, c, sampling)

if nargin < 4
    sampling = 'uniform';
end

% Column Selection
if strcmp(sampling, 'uniform')
    idx = UniformColSampling(K, c);
elseif strcmp(sampling, 'uniform-adaptive2')
    idx = Adaptive2UniformColSampling(K, k, c);
elseif strcmp(sampling, 'near-opt-adaptive')
    idx = AdaptiveNearOptColSampling(K, k, c);
elseif strcmp(sampling, 'adaptive-full')
    idx = AdaptiveFullSampling(K, c);
else
    return;
end

% The Modified Nystrom Approximation
% different from but equivalent to the paper
C = K(:, idx);
[UC, tmp1, tmp2] = svd(C, 'econ');
U = UC' * K * UC;
C = UC;


end